# -*- coding: utf-8 -*-
# @Date    : 2021/6/24
# @Author  : ryenzhang
# @FileName: weight2fbx.py
# @Project : Video_Facap
# @IDE     : PyCharm
# ==============================================================================
from FBX_utils.AnimGeneratorFBX import Generator
import json
import pandas as pd


class FBXG(object):
    def __init__(self, FACS_file="FACS_list.txt", frame_file="52face.xlsx", fbx_file="FACS_xishi_52bs_v2.fbx"):
        facsnames = open(FACS_file, "r")
        facslines = facsnames.readlines()
        self.facs_names = [each_name.replace("\n", "") for each_name in facslines[:51]]
        self.pose_name = [each_name.replace("\n", "") for each_name in facslines[52:]]
        frames = pd.read_excel(frame_file, header=0)
        self.frame_list = {}
        for index, row in frames.iterrows():
            self.frame_list[row["facsname"]] = row["index"]
        self.generator = Generator(fbx_file, self.frame_list)

    def initialize_anim(self, frame_rate):
        self.generator.initialize_animation(frame_rate=int(frame_rate))

    def process(self, exp_weights, pose_paras, frame_index):
        exp_weights_dict = {}
        for index in range(51):
            exp_weights_dict[self.facs_names[index]] = exp_weights[index]
        self.generator.insert_animation_frame(exp_weights_dict, pose_paras, frame_index)

    def save_animation(self, output_path):
        # save json
        with open(output_path + ".json", 'w') as f:
            json.dump(self.generator.animation_fbx_dict, f)
        # save fbx
        self.generator.save_animation(output_path)
