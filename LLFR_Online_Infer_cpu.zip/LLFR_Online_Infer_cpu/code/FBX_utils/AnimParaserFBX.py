from FBX_utils.fbxloader import importScene
import re
from FBX_utils.ParaserFbx import fbximport
from FBX_utils.fbxexporter import fbxexport
import sys
sys.path.append('/Applications/Autodesk/FBX Python SDK/2020.2/lib/Python37_x64/')
sys.path.append('/Applications/Autodesk/FBX Python SDK/2020.2/samples/ImportScene/')
from FbxCommon import *


class FBX_Parser(object):
    def __init__(self):
        self.fbx_dict = None
        self.lScene = None
        self.lSdkManager = None
        self.lAnimStack = None
        self.node_list = None
        self.bs_node_paras = None

    def load_fbx(self, fbx_path, bs_frame_dict):
        self.lScene, self.lSdkManager = importScene(fbx_path)
        self.lAnimStack = self.lScene.GetSrcObject(FbxCriteria.ObjectType(FbxAnimStack.ClassId), 0)
        self.fbx_dict = fbximport(self.lScene)
        self.node_list = list(self.fbx_dict.keys())[12:]
        self.bs_node_paras = {}
        self.parse_bs_node_paras(bs_frame_dict=bs_frame_dict)

    def parse_bs_node_paras(self, bs_frame_dict=None):
        # 遍历所有骨骼
        if bs_frame_dict:
            for each_node_key in self.node_list:
                self.bs_node_paras[each_node_key] = {}
                # 遍历所有参数
                for each_property in list(self.fbx_dict[each_node_key].keys())[:6]:
                    self.bs_node_paras[each_node_key][each_property] = {}
                    # 遍历所有表情基
                    for bs_key in bs_frame_dict.keys():
                        # print('++++++\n',each_node_key,each_anim_key,bs_key,bs_frame_dict[bs_key])
                        self.bs_node_paras[each_node_key][each_property][bs_key] = self.fbx_dict[each_node_key][each_property][bs_frame_dict[bs_key]].copy()
                        if not bs_key == "neutral":
                            self.bs_node_paras[each_node_key][each_property][bs_key][1] -= self.fbx_dict[each_node_key][each_property][bs_frame_dict["neutral"]][1]
            # print("Parsed Node Parameters of Blend Shapes!")

    def convert2atomdict(self, anim_info_dict):
        atom_dict = {'dagNode': {}}
        max_len = 0
        for bone_name in anim_info_dict:
            atom_dict['dagNode'][bone_name] = {}
            for proper in anim_info_dict[bone_name]:
                atom_dict['dagNode'][bone_name][proper] = {'animData': {'keys': anim_info_dict[bone_name][proper]}} #not copy
                max_len = max(max_len, len(anim_info_dict[bone_name][proper]))
        atom_dict['endTime'] = max_len
        self.fbx_dict = atom_dict
        return atom_dict

    def covert2animdict(self, anim_info_dict, atom_dict):
        for bone_name in anim_info_dict:
            for proper in anim_info_dict[bone_name]:
                anim_info_dict[bone_name][proper] = atom_dict['dagNode'][bone_name][proper]['animData']['keys']

    def check_atom_dict(self, anim_info_dict, anim_info_dict2):
        for bone in self.fbx_dict:
            for prop in self.fbx_dict[bone]:
                if len(self.fbx_dict[bone][prop]) == 0:
                    continue
                try:
                    if self.fbx_dict[bone][prop] != anim_info_dict2[bone][prop]:
                        print(bone, prop)
                except KeyError as e:
                    print(bone, prop)
                    import pdb; pdb.set_trace()

    def parse_fbx_anim(self, anim_file):
        with open(anim_file, 'r') as f:
            lines = f.readlines()
        lines_info = []
        anim_info_dict = {}
        last_node_name = ''
        last_param_name = ''
        for each_line in lines:
            each_line = each_line.strip()
            if len(each_line) != 0:
                lines_info.append(each_line)
            if each_line.startswith('Node Name: '):
                last_node_name = each_line[len('Node Name: '):]
                anim_info_dict[last_node_name] = {}
            if each_line in ['TX', 'TY', 'TZ', 'RX', 'RY', 'RZ', 'SX', 'SY', 'SZ']:
                last_param_name = each_line
                anim_info_dict[last_node_name][each_line] = []
            if each_line.startswith('Key Time: '):
                res = re.match(r'Key Time: (.*).... Key Value: (.*) \[ \? \]', each_line, re.M | re.I).groups()
                assert len(res) == 2
                try:
                    frame_idx = int(float(res[0]))
                    keyValue = float(res[1])
                    anim_info_dict[last_node_name][last_param_name].append((frame_idx, keyValue))
                except ValueError as e:
                    pass
        return anim_info_dict

    def set_frame_rate(self, frame_rate):
        frame_interval = 1
        if frame_rate == 120:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMozde(8))
            frame_interval = 4
        elif frame_rate == 100:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMode(7))
        elif frame_rate == 60:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMode(6))
            frame_interval = 2
        elif frame_rate == 50:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMode(5))
        elif frame_rate == 30:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMode(3))
        elif frame_rate == 25:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMode(2))
        elif frame_rate == 24:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMode(1))
        else:
            self.lScene.GetGlobalSettings().SetTimeMode(FbxTime.EMode(3))
            frame_interval = 1
            print("Using default frame mode of 30.0 fps!")
        return frame_interval

    def set_frame_length(self, anim_length, frame_interval):
        anim_length = int((anim_length - 1)/frame_interval) + 1
        TimeSpan = FbxTimeSpan()
        Start = FbxTime()
        Start.SetFrame(0)
        Stop = FbxTime()
        Stop.SetFrame(anim_length)
        TimeSpan.Set(Start, Stop)
        self.lScene.GetGlobalSettings().SetTimelineDefaultTimeSpan(TimeSpan)
        self.lAnimStack.SetLocalTimeSpan(TimeSpan)
        self.lAnimStack.SetReferenceTimeSpan(TimeSpan)

    def save_fbx(self, animation_atom_dict, output_path):
        fbxexport(self.lScene, animation_atom_dict, self.lSdkManager, output_path)

    def destory(self):
        self.lSdkManager.Destroy()


if __name__ == '__main__':
    # anim_info_dict = paraser_fbx(anim_file = '/Users/ljc/Desktop/face/tmp2/TDLEAG/FBX_utils/anima.txt')
    # pass

    fbx = FBX_Paraser('/Users/ljc/Desktop/face/tmp2/TDLEAG/FBX_utils/face_head_base.FBX')
    print(fbx.anim_info_dict)




