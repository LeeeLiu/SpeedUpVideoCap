from FBX_utils.animParaser import FBX_Paraser
import re
import os
import time
from FBX_utils.fbxloader import save_fbx

use_part_list = [
    'Bone002',
    'Bone003',
    'Bone004',
    'Bone005',
    'R_Corner_sec_jnt',
    'L_Corner_sec_jnt',
    'jaw_01_joint_Trsm',
    'LwrLip_sec_jnt',
    'L_lwrLip01_sec_jnt',
    'R_lwrLip01_sec_jnt',
    'UprLip_sec_jnt',
    'L_UprLip_sec_jnt',
    'R_UprLip_sec_jnt',
    'Bip001 Facebone_nose',
    'Bip001 Facebone_nose001',
    'Bip001 Facebone_faceR',
    'Bip001 Facebone_faceL',
    'Bip001 Facebone_faceR1',
    'Bip001 Facebone_faceL1',
    'Bip001 Facebone_faceR002',
    'Bip001 Facebone_faceL002',
    'Bip001 Facebone_eyebrow01',
    'Bip001 Facebone_eyebrowR04',
    'Bip001 Facebone_eyebrowR05',
    'Bip001 Facebone_eyebrowL04',
    'Bip001 Facebone_eyebrowL05',
    'L_Brow_1_sec_jnt',
    'R_Brow_1_sec_jnt',
    'L_Brow_2_sec_jnt',
    'L_Brow_3_sec_jnt',
    'R_Brow_2_sec_jnt',
    'R_Brow_3_sec_jnt',
    'Bip001 Facebone_eyeL',
    'Bip001 Facebone_eyeR',
    'Bip001 Facebone_eyeRD03',
    'Bip001 Facebone_eyeLD03',
    'FACIAL_L_EyelidLowerA',
    'L_LwrLid_1_sec_jnt',
    'L_LwrLid_2_sec_jnt',
    'L_LwrLid_3_sec_jnt',
    'FACIAL_L_EyelidUpperA',
    'L_UprLid_1_sec_jnt',
    'L_UprLid_2_sec_jnt',
    'FACIAL_R_EyelidLowerA',
    'R_LwrLid_1_sec_jnt',
    'R_LwrLid_2_sec_jnt',
    'R_LwrLid_3_sec_jnt',
    'FACIAL_R_EyelidUpperA',
    'R_UprLid_2_sec_jnt',
    'R_UprLid_1_sec_jnt',
    'L_LidInn_1_sec_jnt',
]


def fbx_dict(fbx_path, max_len=11):
    target_fbx = FBX_Paraser(fbx_path)
    for bone_key in target_fbx.anim_info_dict.keys():
        if bone_key in use_part_list:
            for para_item in target_fbx.anim_info_dict[bone_key].keys():
                print(bone_key, para_item, len(target_fbx.anim_info_dict[bone_key][para_item]))
                if len(target_fbx.anim_info_dict[bone_key][para_item]) < max_len:
                    print('----------', bone_key, para_item, len(target_fbx.anim_info_dict[bone_key][para_item]))
                    # neur_frame = target_fbx.anim_info_dict[bone_key][para_item][0]
                    # new_para_item = []
                    # count = 0
                    # for i in range(max_len):
                    #     if target_fbx.anim_info_dict[bone_key][para_item][count][0] == i:
                    #         count += 1
                    #         new_para_item.append(target_fbx.anim_info_dict[bone_key][para_item][count])
                    #     else:
                    #         neur_frame[0] = i
                    #         new_para_item.append(neur_frame)
                    # target_fbx.anim_info_dict[bone_key][para_item] = new_para_item
    target_fbx.destory()
    return target_fbx


if __name__ == '__main__':
    target_fbx = fbx_dict('/Users/ljc/Desktop/face/Emotion_OSG/vism_atom/ExpressionLibrary/OSG_Emotion_29.FBX', max_len=2)

    # target_fbx = fbx_dict('/Users/ljc/Desktop/face/Emotion_OSG/vism_atom/ExpressionLibrary/OSG_Emotion.FBX', max_len=26)

    # fbx_dict('/Users/ljc/Desktop/face/Emotion_OSG/FBX_utils/face_head_base.FBX',max_len=37)

    # print(target_fbx.anim_info_dict['L_Brow_1_sec_jnt']['TX'])
    # save_fbx('E:/数字人/OSG/code/OSG_Lip.FBX', target_fbx.anim_info_dict, 'fix_lip.fbx')
