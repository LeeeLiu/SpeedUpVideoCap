# -*- coding: utf-8 -*-

__author__ = 'axuli & ryen & leeeliu'

import os
import cv2
import argparse
import imageio
import numpy as np
from tqdm import tqdm
import time
from llfr import LLFR
from FaceBoxes.FaceBoxes_ONNX import FaceBoxes_ONNX

# only GPU
# from FaceBoxes.FaceBoxes_tensorRT import FaceBoxes_tensorRT

from FaceBoxes.utils.timer import Timer
from weight2fbx import FBXG

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
# imageio.plugins.ffmpeg.download()


def run_offline_image():
    pass


def open_video():
    fp, fn = os.path.split(args.input_path.replace(" ", "\ "))
    command = "ffmpeg -threads 10 -i %s -r 30 -y -crf 20 -vcodec h264 %s " % (
    args.input_path.replace(" ", "\ "), os.path.join(args.output_path, fn))
    return_value = os.system(command)
    return fp, fn

def measure_speed(id, f, onnx_faceBox=True, onnx_llfr=False, rt_faceBox=False, rt_llfr=False):  
    '''
    Author: leeeLiu
    Args:
        f: TXT file where forward_pass_time will be written into
        onnx_faceBox: faceBox with onnx
        onnx_llfr: llfr with onnx
        rt_faceBox: faceBox with tensorRT
        rt_llfr: llfr with tensorRT
    Returns:
        when this function ends, please open TXT file and check the result.
    '''
 
    fp, fn = open_video()
    videoCapture = cv2.VideoCapture()
    videoCapture.open(os.path.join(args.output_path, fn))
    frame_num = videoCapture.get(cv2.CAP_PROP_FRAME_COUNT)
    frame_rate = videoCapture.get(cv2.CAP_PROP_FPS)
    height = int(videoCapture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    width = int(videoCapture.get(cv2.CAP_PROP_FRAME_WIDTH))
    arch, dropout = parse_model()

    if rt_llfr:
        from llfr import LLFR_tensorRT
        llfr = LLFR_tensorRT(args.weights, arch, dropout, height=height, num_class=args.num_class)
    else:
        if onnx_llfr:
            from llfr import LLFR_ONNX
            llfr = LLFR_ONNX(args.weights, arch, dropout, height=height, num_class=args.num_class)
        else:
            llfr = LLFR(args.weights, arch, dropout, height=height, num_class=args.num_class)

    if rt_faceBox:
        faceboxes = FaceBoxes_tensorRT(height,width)
    else:
        if onnx_faceBox:
            faceboxes = FaceBoxes_ONNX()
        else:
            from FaceBoxes.FaceBoxes import FaceBoxes
            faceboxes = FaceBoxes()

    fbxg = FBXG()
    fbxg.initialize_anim(frame_rate)
    video_wfp = os.path.join(args.output_path, fn).replace('.mp4', '_res{}.mp4'.format(id))
    writer = imageio.get_writer(video_wfp, fps=frame_rate)

    time_consume = {'forward_pass': Timer()}
    for index in tqdm(range(int(frame_num))):
        success, frame_BGR = videoCapture.read()
        #frame_bgr = frame_BGR
        # (1080, 1920, 3)
        h, w = round(480*3), round(270*3)
        frame_bgr = np.array([cv2.resize(roi_face, (h, w)) for roi_face in frame_BGR.transpose((2, 0, 1))]).transpose(1, 2, 0)
        
        time_consume['forward_pass'].tic()
        bboxes = faceboxes(frame_bgr)
        res, cropped_face, tdmm_weights, headpose, eyepose = llfr(frame_bgr, bboxes, index)
        time_consume['forward_pass'].toc()

        frame_bgr[-256:, -256:, :] = cropped_face
        image = np.concatenate((frame_BGR, res), axis=1)
        writer.append_data(image[..., ::-1])
        if args.save_fbx:
            fbxg.process(tdmm_weights[0], np.concatenate((headpose[0], eyepose[0])), index)

    f.write('When onnx_faceBox={}, onnx_llfr={} \n'.format(onnx_faceBox, onnx_llfr))
    f.write('     rt_faceBox={},   rt_llfr={} \n'.format(rt_faceBox, rt_llfr))
    f.write('forward_pass_time: {:.4f}s \n\n'.format(time_consume['forward_pass'].average_time))
    writer.close()

    if not args.save_video:
        os.system("rm %s" % os.path.join(args.output_path, fn))
    if args.save_fbx:
        fbxg.save_animation(os.path.join(args.output_path, fn).replace(".mp4", ""))
        print(f"Animation Dump to %s" % os.path.join(args.output_path, fn).replace(".mp4", ".fbx"))
    print(f'Video Dump to {video_wfp}')



def run_offline_video():
    fp, fn = os.path.split(args.input_path.replace(" ", "\ "))
    command = "ffmpeg -threads 10 -i %s -r 30 -y -crf 20 -vcodec h264 %s " % (args.input_path.replace(" ", "\ "), os.path.join(args.output_path, fn))
    return_value = os.system(command)

    videoCapture = cv2.VideoCapture()
    videoCapture.open(os.path.join(args.output_path, fn))
    frame_num = videoCapture.get(cv2.CAP_PROP_FRAME_COUNT)
    frame_rate = videoCapture.get(cv2.CAP_PROP_FPS)
    height = int(videoCapture.get(cv2.CAP_PROP_FRAME_HEIGHT))

    arch, dropout = parse_model()
    llfr = LLFR(args.weights, arch, dropout, height=height, num_class=args.num_class)
    faceboxes = FaceBoxes_ONNX()
    fbxg = FBXG()
    fbxg.initialize_anim(frame_rate)
    video_wfp = os.path.join(args.output_path, fn).replace('.mp4', '_res.mp4')
    writer = imageio.get_writer(video_wfp, fps=frame_rate)
    
    for index in tqdm(range(int(frame_num))):
        success, frame_bgr = videoCapture.read()
        bboxes = faceboxes(frame_bgr)
        res, cropped_face, tdmm_weights, headpose, eyepose = llfr(frame_bgr, bboxes, index)
        frame_bgr[-256:, -256:, :] = cropped_face
        image = np.concatenate((frame_bgr, res), axis=1)
        writer.append_data(image[..., ::-1])
        if args.save_fbx:
            fbxg.process(tdmm_weights[0], np.concatenate((headpose[0], eyepose[0])), index)
    writer.close()
    if not args.save_video:
        os.system("rm %s" % os.path.join(args.output_path, fn))
    if args.save_fbx:
        fbxg.save_animation(os.path.join(args.output_path, fn).replace(".mp4", ""))
        print(f"Animation Dump to %s" % os.path.join(args.output_path, fn).replace(".mp4", ".fbx"))
    print(f'Video Dump to {video_wfp}')


def run_online_video():
    arch, dropout = parse_model()
    llfr = LLFR(args.weights, arch, dropout, num_class=args.num_class)
    faceboxes = FaceBoxes_ONNX()

    # # Given a came
    reader = imageio.get_reader("<video0>", input_params=['-framerate', '30'])    # rgb
    [width, height] = reader.get_meta_data()['size']
    if args.save_video:
        video_wfp = os.path.join(args.output_path, time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime()) + '_res.mp4')
        writer = imageio.get_writer(video_wfp, fps=30)
    for i, frame in tqdm(enumerate(reader)):
        st = time.time()
        frame_bgr = frame[..., ::-1]  # RGB->BGR
        bboxes = faceboxes(frame_bgr)

        res, cropped_face, tdmm_weights, headpose, eyepose = llfr(frame_bgr, bboxes, i)
        frame_bgr[-256:, -256:, :] = cropped_face
        image = np.concatenate((frame_bgr, res), axis=1)
        cost = time.time() - st
        fps = 1.0 / cost
        image = cv2.putText(image, f"%dx%d %.2f FPS" % (width, height, fps), (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
        cv2.imshow('res_video', image)
        if args.save_video:
            writer.append_data(image[..., ::-1])
        if (cv2.waitKey(20) & 0xff == ord('q')):
            break
    if args.save_video:
        writer.close()
        print(f'Video Dump to {video_wfp}')


def run_online_compare():
    arch, dropout = parse_model()
    llfr = LLFR(args.weights, arch, dropout, num_class=args.num_class)
    llfr_compared = LLFR(args.weights_compared, arch, dropout, num_class=args.num_class_compared)
    faceboxes = FaceBoxes_ONNX()

    # # Given a came
    reader = imageio.get_reader("<video0>", input_params=['-framerate', '30'])    # rgb
    [width, height] = reader.get_meta_data()['size']
    if args.save_video:
        video_wfp = os.path.join(args.output_path, time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime()) + '_res.mp4')
        writer = imageio.get_writer(video_wfp, fps=30)
    for i, frame in tqdm(enumerate(reader)):
        st = time.time()
        frame_bgr = frame[..., ::-1]  # RGB->BGR
        bboxes = faceboxes(frame_bgr)

        res, cropped_face, tdmm_weights, headpose, eyepose = llfr(frame_bgr, bboxes, i)
        res_compared, cropped_face_compared, tdmm_weights, headpose, eyepose = llfr_compared(frame_bgr, bboxes, i)
        frame_bgr[-256:, -256:, :] = cropped_face
        res = cv2.putText(res, "new model", (30, 100), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
        res_compared = cv2.putText(res_compared, "old model", (30, 100), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
        image = np.concatenate((frame_bgr, res, res_compared), axis=1)
        cost = time.time() - st
        fps = 1.0 / cost
        image = cv2.putText(image, f"%dx%d %.2f FPS" % (width, height, fps), (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
        cv2.imshow('res_video', image)
        if args.save_video:
            writer.append_data(image[..., ::-1])
        if (cv2.waitKey(20) & 0xff == ord('q')):
            break
    if args.save_video:
        writer.close()
        print(f'Video Dump to {video_wfp}')
    

def run_online_video_cv2():
    arch, dropout = parse_model()
    llfr = LLFR(args.weights, arch, dropout, num_class=args.num_class)
    faceboxes = FaceBoxes_ONNX()

    # # Given a came
    videoCapture = cv2.VideoCapture(0)
    width = videoCapture.get(3)
    height = videoCapture.get(4)
    success, frame_bgr = videoCapture.read()
    i = 0
    while success:
        st = time.time()
        bboxes = faceboxes(frame_bgr)
        res, cropped_face = llfr(frame_bgr, bboxes, i)
        i += 1
        frame_bgr[-256:, -256:, :] = cropped_face
        image = np.concatenate((frame_bgr, res), axis=1)
        cost = time.time() - st
        fps = 1.0 / cost
        image = cv2.putText(image, f"%dx%d %.2f FPS" % (width, height, fps), (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL,
                            1.2, (0, 255, 0), 2)
        cv2.imshow('res_video', image)
        if (cv2.waitKey(20) & 0xff == ord('q')):
            break
        success, frame_bgr = videoCapture.read()


def parse_model():
    arch = os.path.split(args.weights)[-1].split('_')[0]
    dropout = float(os.path.split(args.weights)[-1].split('_')[1])
    return arch, dropout


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", type=str, default="webcam")  # webcam or video or image or campare
    parser.add_argument("--video-tool", type=str, default="imageio")  # imageio or opencv
    parser.add_argument("--save-video", type=bool, default=False)
    # todo 优化三重循环，修改这里参数
    parser.add_argument("--save-fbx", type=bool, default=False)
    parser.add_argument('--input-path', type=str, default="./examples/input/eyepose.mp4")
    parser.add_argument('--output-path', type=str, default="result")
    parser.add_argument('--weights', type=str,
                        default="./checkpoints/mobilenetv3small_0.5_wpdc_checkpoint_epoch_46_withALL.pth.tar")
    parser.add_argument('--num-class', type=int, default=60)
    parser.add_argument('--weights-compared', type=str,
                        default="./checkpoints/mobilenetv3small_0.5_wpdc_checkpoint_epoch_40.pth.tar")
    parser.add_argument('--num-class-compared', type=int, default=51)
    args = parser.parse_args()
    if not os.path.exists(args.output_path):
        os.mkdir(args.output_path)

    if args.mode == "webcam":
        if args.video_tool == "imageio":
            run_online_video()
        elif args.video_tool == "opencv":
            run_online_video_cv2()
    elif args.mode == "video":
        run_offline_video()
    elif args.mode == "image":
        run_offline_image()
    elif args.mode == "compare":
        run_online_compare()
    elif args.mode == "measure_speed":
        f = open("txt/OutputInfo.txt", "w")
        measure_speed(1, f)
        measure_speed(2, f, onnx_llfr=True)

        # only GPU
        # measure_speed(3, f, onnx_llfr=True, rt_faceBox=True)
        # only GPU
        # measure_speed(4, f, onnx_llfr=True, rt_faceBox=True, rt_llfr=True)
        f.close()
    else:
        print("Please select correct mode.")
