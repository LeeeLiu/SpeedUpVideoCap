# -*- coding: utf-8 -*-

__author__ = 'axuli'

import torch.nn as nn
from torch.nn.init import xavier_uniform_, constant_
import models

model_zoo = [
    'resnet18', 'resnet34', 'resnet50', 'resnet101', 'resnet152',
    'MobileNet', 'mobilenetv1', 'MobileNetV2', 'mobilenetv2',
    "MobileNetV3", "mobilenetv3large", "mobilenetv3small",
    'ShuffleNetV2', 'shufflenet_v2_x0_5', 'shufflenet_v2_x1_0', 'shufflenet_v2_x1_5', 'shufflenet_v2_x2_0',
]
        
class Model(nn.Module):
    """LLFR: named Live Link Face Regression (LLFR)"""
    def __init__(self, num_class=51, base_model='resnet50', 
                 dropout=0, pretrained=False):
        super(Model, self).__init__()
        self.dropout = dropout
        self.base_model_name = base_model
        self.pretrained = pretrained

        self._prepare_base_model(base_model)
        self._prepare_llfr(num_class)


    def _prepare_base_model(self, base_model):
        if base_model in model_zoo:
            self.base_model = getattr(models, base_model)(pretrained=self.pretrained)
            self.base_model.last_layer_name = 'fc'
            self.input_size = 224
            self.input_mean = [0.485, 0.456, 0.406]
            self.input_std = [0.229, 0.224, 0.225]
        else:
            raise ValueError('Unknown base model: {}'.format(base_model))

    def _prepare_llfr(self, num_class):
        feature_dim = getattr(self.base_model, self.base_model.last_layer_name).in_features
        if self.dropout == 0:
            setattr(self.base_model, self.base_model.last_layer_name, nn.Linear(feature_dim, num_class))
            self.new_fc = None
        else:
            setattr(self.base_model, self.base_model.last_layer_name, nn.Dropout(p=self.dropout))
            self.new_fc = nn.Linear(feature_dim, num_class)

        if self.new_fc is None:
            xavier_uniform_(getattr(self.base_model, self.base_model.last_layer_name).weight)
            constant_(getattr(self.base_model, self.base_model.last_layer_name).bias, 0)
        else:
            xavier_uniform_(self.new_fc.weight)
            constant_(self.new_fc.bias, 0)

    def forward(self, input):
        out = self.base_model(input)
        
        if self.dropout > 0:
            out = self.new_fc(out)
            
        return out.squeeze(1)