# coding: utf-8

__author__ = 'axuli'

import sys
sys.path.append('..')


import pickle
import numpy as np
from math import cos, sin


class AppleModel(object):
    def __init__(self, apple_fp='./apple/apple.pkl'):
        apple = pickle.load(open(apple_fp,'rb'))
        
        self.neu = apple.get('neu').astype(np.float32)
        self.tri = apple.get('tri').astype(np.int32)
        self.bs_exps = apple.get('bs_exps').astype(np.float32)
        self.bs_name = apple.get('bs_name')
    
    def recon_vers(self, exp_weights):
        '''
        exp_weight: (1, 51)
        '''
        exp_delta = np.einsum('ij, jkl->ikl', exp_weights, self.bs_exps)
        exp_delta = np.squeeze(exp_delta, axis=0)
        vertices = self.neu + exp_delta
        return vertices

    def recon_rotated_vers(self, exp_weights, headpose):
        '''
        exp_weight: (1, 51)
        headpose: [pitch, yaw, roll]
        '''
        exp_delta = np.einsum('ij, jkl->ikl', exp_weights, self.bs_exps)

        exp_delta = np.squeeze(exp_delta, axis=0)
        vertices = self.neu + exp_delta

        R = self.angle2matrix(headpose)
        rotated_vertices = vertices.dot(R.T)

        return rotated_vertices

    def get_neutral(self):
        return self.recon_vers(np.zeros((1, 51)))

    def angle2matrix(self, angles): 
        # pitch yaw roll 
        # x, y, z = np.deg2rad(angles[1]), -np.deg2rad(angles[0]), -np.deg2rad(angles[2])
        x, y, z = -angles[1], -angles[0], -angles[2]
        Rx = np.array([[1,      0,       0],
                    [0, cos(x),  -sin(x)],
                    [0, sin(x),   cos(x)]])
        Ry = np.array([[cos(y), 0, sin(y)],
                    [      0, 1,      0],
                    [-sin(y), 0, cos(y)]])
        Rz = np.array([[cos(z), -sin(z), 0],
                    [sin(z),  cos(z), 0],
                    [     0,       0, 1]])
        R = Rz.dot(Ry.dot(Rx))
        return R.astype(np.float32)


if __name__ == "__main__":
    apple = AppleModel('./apple/apple.pkl')
    neutral = apple.get_neutral()
    exp_weights = np.random.rand(1, 51)
    vertices = apple.recon_vers(exp_weights)
    print(vertices.shape)
