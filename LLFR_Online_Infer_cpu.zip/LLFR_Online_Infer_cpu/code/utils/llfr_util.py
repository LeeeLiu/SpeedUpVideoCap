# coding: utf-8

__author__ = 'axuli'

import cv2
import numpy as np


class FaceBox_Tool(object):
    def __init__(self):
        self.image_name = None
        self.image = None
        self.height = 0
        self.width = 0
        self.scale_ratio = 1.12

    def bounding_box_expanding(self, bbox):
        roi_box = np.zeros(4)
        x_center = (bbox[1] + bbox[3]) / 2.0
        x_distance = bbox[3] - x_center
        y_center =(bbox[0] + bbox[2]) / 2.0
        y_distance = bbox[2] - y_center
        distance = np.maximum(x_distance, y_distance)
        roi_box[1] = int(np.maximum(round(x_center - distance * self.scale_ratio), 0))
        roi_box[3] = int(np.minimum(round(x_center + distance * self.scale_ratio), self.height))
        roi_box[0] = int(np.maximum(round(y_center - distance * self.scale_ratio), 0))
        roi_box[2] = int(np.minimum(round(y_center + distance * self.scale_ratio), self.width))
        roi_box = roi_box.astype(int)
        return roi_box

    def __call__(self, img_bgr, bboxes):
        # Load original image
        self.image = img_bgr  # bgr
        [self.height, self.width] = self.image.shape[:2]
        if len(bboxes) > 0:
            if len(bboxes) > 1:
                bboxes = self.rio_filter(bboxes)
            roi_box_list = [self.bounding_box_expanding(each_bb) for each_bb in bboxes]
            roi_faces = [self.image[each_roi_bb[1]: each_roi_bb[3], each_roi_bb[0]: each_roi_bb[2]] for each_roi_bb in roi_box_list]
            resizeed_faces = [cv2.resize(roi_face, (256, 256)) for roi_face in roi_faces]
            return resizeed_faces[0]
        else:
            return None

    def rio_filter(self, bboxes):
        face_index = 0
        face_num = len(bboxes)
        height = 0
        for each_face_index in range(face_num):
            tmp_height = bboxes[each_face_index][3] - bboxes[each_face_index][1]
            center_x = (bboxes[each_face_index][3] + bboxes[each_face_index][1]) / 2.0
            center_y = (bboxes[each_face_index][2] + bboxes[each_face_index][0]) / 2.0
            distance = np.sqrt((center_x - self.height / 2.0)**2 + (center_y - self.width / 2.0)**2)
            ratio = 1 - distance / np.sqrt((self.height / 2.0)**2 + (self.width / 2.0)**2)
            if tmp_height * ratio > height:
                face_index = each_face_index
                height = tmp_height * ratio
        return [bboxes[face_index]]