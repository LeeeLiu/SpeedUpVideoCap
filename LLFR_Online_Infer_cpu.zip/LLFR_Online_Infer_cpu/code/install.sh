#!/usr/bin/env bash 

cd utils/asset
#gcc -shared -Wall -O3 render.c -o render.so -fPIC

D:/LT/mingw-w64/x86_64-8.1.0-win32-seh-rt_v6-rev0/mingw64/bin/gcc -m64 -shared -Wall -O3 render.c -o render.dll -fPIC # for windows
cd ../..

cd FaceBoxes
sh build_cpu_nms.sh
cd ..
