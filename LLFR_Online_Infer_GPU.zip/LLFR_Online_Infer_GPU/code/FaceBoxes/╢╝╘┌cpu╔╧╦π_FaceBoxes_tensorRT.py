# coding: utf-8

import os.path as osp
import torch
import numpy as np
import cv2


from .utils.prior_box import PriorBox
from .utils.nms_wrapper import nms
from .utils.box_utils import decode
from .utils.timer import Timer
from .utils.config import cfg

from .onnx import convert_to_onnx
import onnxruntime

# some global configs
confidence_threshold = 0.05
top_k = 5000
keep_top_k = 750
nms_threshold = 0.3
vis_thres = 0.5
resize = 1

HEIGHT, WIDTH = 720, 1080

make_abs_path = lambda fn: osp.join(osp.dirname(osp.realpath(__file__)), fn)
onnx_path = make_abs_path('weights/FaceBoxesProd.onnx')


# leeeliu
import pycuda.driver as cuda
import pycuda.autoinit
import sys, os
import tensorrt as trt
sys.path.insert(1, os.path.join(sys.path[0], ".."))
import tensorRT_utils as common


TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
#TRT_LOGGER = trt.Logger(trt.Logger.VERBOSE)


def build_engine_onnx(model_file, img_height, img_width):
    with trt.Builder(TRT_LOGGER) as builder, builder.create_network(
            common.EXPLICIT_BATCH) as network, trt.OnnxParser(network, TRT_LOGGER) as parser:
        builder.max_workspace_size = common.GiB(1)
        # Load the Onnx model and parse it in order to populate the TensorRT network.
        with open(model_file, 'rb') as model:
            if not parser.parse(model.read()):
                print('ERROR: Failed to parse the ONNX file.')
                for error in range(parser.num_errors):
                    print(parser.get_error(error))
                return None

        profile = builder.create_optimization_profile()
        
        profile.set_shape("input", (1, 3, img_height, img_width), (1, 3, img_height, img_width), (1, 3, img_height, img_width))

        #profile.set_shape("input", (1, 3, img_height, img_width) )


        config = builder.create_builder_config()
        config.add_optimization_profile(profile)
        return builder.build_engine(network, config)
        # return builder.build_cuda_engine(network)


scale_flag = True  # todo
scale = 1
class FaceBoxes_tensorRT(object):
    def __init__(self, h, w, timer_flag=False):
        global scale
        if scale_flag:
            if h > HEIGHT:
                scale = HEIGHT / h
            if w * scale > WIDTH:
                scale *= WIDTH / (w * scale)
            
            if scale == 1:
                self.h_s = h
                self.w_s = w
            else:
                self.h_s = int(scale * h)
                self.w_s = int(scale * w)
        else:
            self.h_s = h
            self.w_s = w

        self.timer_flag = timer_flag
        if not osp.exists(onnx_path):
            convert_to_onnx(onnx_path)

        # 替换1
        # self.session = onnxruntime.InferenceSession(onnx_path, None, )
        self.softmax = torch.nn.Softmax(dim=-1)
        engine = build_engine_onnx(onnx_path, self.h_s, self.w_s)
        self.inputs, self.outputs, self.bindings, self.stream = common.allocate_buffers(engine)
        self.context = engine.create_execution_context()
        # self.context.set_binding_shape(0, (1, 3, im_height, im_width))

    def __call__(self, img_):
        img, scale_bbox, scale, im_height, im_width = self.preprocess(img_)

        # loc, conf = self.net(img)  # forward
        # out = self.session.run(None, {'input': img})
        # loc, conf = out[0], out[1]

# 替换2
        np.copyto(self.inputs[0].host, img.reshape(-1))

        _t = {'forward_pass': Timer()}
        _t['forward_pass'].tic()
        trt_outputs = common.do_inference_v2(self.context, bindings=self.bindings,
                                             inputs=self.inputs, outputs=self.outputs, stream=self.stream)
        _t['forward_pass'].toc()

        loc = trt_outputs[0].reshape(1, -1, 4)
        conf = (trt_outputs[1]).reshape(1, -1, 2)
        #conf = self.softmax(torch.from_numpy(conf))
        #conf = conf.cpu().numpy()
        # loc = torch.from_numpy(loc)

# 替换2

        det_bboxes = self.boxes_filter(loc, conf, scale_bbox, scale, im_height, im_width)

        return det_bboxes, _t['forward_pass'].average_time


    def preprocess(self, img_):
        img_raw = img_.copy()
        # scaling to speed up
        # scale = 1
        # if scale_flag:
        #     h, w = img_raw.shape[:2]
        #     if h > HEIGHT:
        #         scale = HEIGHT / h
        #     if w * scale > WIDTH:
        #         scale *= WIDTH / (w * scale)
        #     # print(scale)
        #     if scale == 1:
        #         img_raw_scale = img_raw
        #     else:
        #         h_s = int(scale * h)
        #         w_s = int(scale * w)
        #         # print(h_s, w_s)
        #         img_raw_scale = cv2.resize(img_raw, dsize=(w_s, h_s))
        #         # print(img_raw_scale.shape)
        #
        #     img = np.float32(img_raw_scale)
        # else:
        #     img = np.float32(img_raw)

        img = np.float32(cv2.resize(img_raw, dsize=(self.w_s, self.h_s)))

        im_height, im_width, _ = img.shape
        scale_bbox = np.array([img.shape[1], img.shape[0], img.shape[1], img.shape[0]])

        img -= (104, 117, 123)
        img = img.transpose(2, 0, 1)
        # img = torch.from_numpy(img).unsqueeze(0)
        img = img[np.newaxis, ...]
        return img, scale_bbox, scale, im_height, im_width

    def boxes_filter(self, loc, conf, scale_bbox, scale, im_height, im_width):
        priorbox = PriorBox(image_size=(im_height, im_width))
        priors = priorbox.forward()
        # priors = priors.data
        boxes = decode(loc.squeeze(0), priors, cfg['variance'])
        if scale_flag:
            boxes = boxes * scale_bbox / scale / resize
        else:
            boxes = boxes * scale_bbox / resize
        scores = conf[0][:, 1]
        # scores = conf.squeeze(0).data.cpu().numpy()[:, 1]

        # ignore low scores
        inds = np.where(scores > confidence_threshold)[0]
        boxes = boxes[inds]
        scores = scores[inds]

        # keep top-K before NMS
        order = scores.argsort()[::-1][:top_k]
        boxes = boxes[order]
        scores = scores[order]

        # do NMS
        dets = np.hstack((boxes, scores[:, np.newaxis])).astype(np.float32, copy=False)
        keep = nms(dets, nms_threshold)
        dets = dets[keep, :]

        # keep top-K faster NMS
        dets = dets[:keep_top_k, :]

        # filter using vis_thres
        det_bboxes = []
        for b in dets:
            if b[4] > vis_thres:
                xmin, ymin, xmax, ymax, score = b[0], b[1], b[2], b[3], b[4]
                bbox = [xmin, ymin, xmax, ymax, score]
                det_bboxes.append(bbox)
        return det_bboxes

