# -*- coding: utf-8 -*-

__author__ = 'axuli'

import os
import cv2
import imageio
import torch
import numpy as np
from torchvision import transforms

from model import Model
from apple.apple import AppleModel
from utils.render_ctypes import render
from utils.llfr_util import FaceBox_Tool

import onnxruntime
from FaceBoxes.utils.timer import Timer

apple = AppleModel()
facebox_tool = FaceBox_Tool()

transform = transforms.Compose(
            [transforms.ToTensor(), transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.25, 0.25, 0.25])])


class LLFR(object):
    def __init__(self, weights, arch, dropout, f, num_class=60):
        self.num_class = num_class
        checkpoint = torch.load(weights, map_location=torch.device('cpu'))
        model = Model(base_model=arch, dropout=dropout, num_class=num_class)
        model = torch.nn.DataParallel(model)
        model.load_state_dict(checkpoint["state_dict"])
        self.model = model
        self.model.eval()

        self.transform = transforms.Compose(
            [transforms.ToTensor(), transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.25, 0.25, 0.25])])

        self.render_size = 3000
        self.render_width = 1080
        self.render_height = 720
        self.eyepose_sum = np.zeros((1, 6))
        self.default_pose = np.zeros((1, 6))
        self.tdmm_weights = np.zeros((1, 51))
        self.headpose = np.zeros((1, 3))
        self.eyepose = np.zeros((1, 3))

#        self.f = open("resize到多小才会失效/num_not_recognize.txt", "w")
#        self.f.write('')
#        self.f = open("resize到多小才会失效/num_not_recognize.txt", "a")

    def __call__(self, img_bgr, bboxes, index, f, args):
        resized_faces = facebox_tool(img_bgr, bboxes)
        if type(resized_faces) != np.ndarray:
            # self.f.write('1\n')
            # self.f.close()

            vers = apple.neu
            res = self.render_img(vers)
            cv2.putText(res, f"I can't see your face! Rendering Neutral Face!", (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
            self.eyepose = self.default_pose
            resized_faces = np.zeros((256, 256, 3))
        else:
            input_tensor = self.transform(resized_faces).unsqueeze(0)

            timeStamp = Timer()
            timeStamp.tic()
            output = self.model(input_tensor)
            timeStamp.toc()


            self.tdmm_weights, self.headpose, self.eyepose = self.parse_params(output.detach().cpu().numpy())
            # vers = apple.recon_rotated_vers(self.tdmm_weights, self.headpose.squeeze())
            # res = self.render_img(vers)

        # if index < 10:
        #     self.eyepose_sum += self.eyepose
        #     self.default_pose = self.eyepose_sum / (index + 1)
        # res = self.eyepose_render(self.eyepose, res)

#        imageio.imwrite('./resize到多小才会失效/pic/resized_face-{}.png'.format(index), resized_faces)
        return None, resized_faces, self.tdmm_weights, self.headpose, self.eyepose, timeStamp.average_time

    def render_img(self, vers):
        img = np.zeros((self.render_height, self.render_width, 3), dtype=np.uint8)
        vers = vers.T.copy()
        vers[0] = vers[0] * self.render_size + self.render_width / 2
        vers[1] = vers[1] * self.render_size + self.render_height / 2
        vers[2] = vers[2] * self.render_size + self.render_height / 2
        render_res = render(img, [vers], apple.tri)
        return render_res

    def eyepose_render(self, current_pose, frame, distance=10.0):
        current_pose -= self.default_pose
        [LeftEyeYaw, LeftEyePitch, _, RightEyeYaw, RightEyePitch, _] = current_pose[0]
        EyeYaw = (LeftEyeYaw + RightEyeYaw) / 2.0
        EyePitch = (LeftEyePitch + RightEyePitch) / 2.0
        # print(EyeYaw, EyePitch)
        trans_X = np.tan((EyeYaw / np.pi * 180).astype(int) / 180 * np.pi) * distance
        trans_Y = np.tan((EyePitch / np.pi * 180).astype(int) / 180 * np.pi) * -distance

        scale = self.render_width / 10.0
        x = int(trans_X * scale + self.render_width / 2.0)
        y = int(-trans_Y * scale + self.render_height / 2.0)
        img = cv2.circle(frame, (x, y), 4, (0, 0, 255), 8)
        return img

    def parse_params(self, params):
        if self.num_class == 60:
            tdmm = params[:, :51]
            headpose = params[:, 51:54]
            eyepose = params[:, 54:]
        elif self.num_class == 57:
            tdmm = params[:, :51]
            headpose = np.zeros((len(tdmm), 3))
            eyepose = params[:, 51:]
        elif self.num_class == 51:
            tdmm = params[:, :51]
            headpose = np.zeros((len(tdmm), 3))
            eyepose = np.zeros((len(tdmm), 6))
        else:
            print("Please set correct prediction dimension.")
        return tdmm, headpose, eyepose


class LLFR_ONNX(object):
    def __init__(self, weights, arch, dropout, f, num_class=60):

        self.weights = weights
        make_abs_path = lambda fn: os.path.join(os.path.dirname(os.path.realpath(__file__)), fn)
        onnx_path = make_abs_path(weights.replace('.pth', '.onnx'))
        if not os.path.exists(onnx_path):
            self.convert_2_onnx(onnx_path,arch, dropout, num_class)
        self.session = onnxruntime.InferenceSession(onnx_path, None, )

        self.num_class = num_class

        '''
        checkpoint = torch.load(weights, map_location=torch.device('cpu'))
        model = Model(base_model=arch, dropout=dropout, num_class=num_class)
        model = torch.nn.DataParallel(model)
        model.load_state_dict(checkpoint["state_dict"])
        self.model = model
        self.model.eval()
        '''

        self.transform = transforms.Compose(
            [transforms.ToTensor(), transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.25, 0.25, 0.25])])

        self.render_size = 3000
        self.render_width = 1080
        self.render_height = 720
        self.eyepose_sum = np.zeros((1, 6))
        self.default_pose = np.zeros((1, 6))
        self.tdmm_weights = np.zeros((1, 51))
        self.headpose = np.zeros((1, 3))
        self.eyepose = np.zeros((1, 3))

    def __call__(self, img_bgr, bboxes, index, f, args):
        # Given image_brg; Return render result
        resized_faces = facebox_tool(img_bgr, bboxes)
        if type(resized_faces) != np.ndarray:
            vers = apple.neu
            res = self.render_img(vers)
            cv2.putText(res, f"I can't see your face! Rendering Neutral Face!", (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
            self.eyepose = self.default_pose
            resized_faces = np.zeros((256, 256, 3))
        else:
            input_tensor = self.transform(resized_faces).unsqueeze(0)
            # torch.Size([1, 3, 256, 256])
            # output = self.model(input_tensor)

            timeStamp = Timer()
            timeStamp.tic()
            output = self.session.run(None, {'input': input_tensor.cpu().numpy().astype(np.float32)})
            timeStamp.toc()

            self.tdmm_weights, self.headpose, self.eyepose = self.parse_params(np.array(output).squeeze(0))
            # vers = apple.recon_rotated_vers(self.tdmm_weights, self.headpose.squeeze())
            # res = self.render_img(vers)

        # if index < 10:
        #     self.eyepose_sum += self.eyepose
        #     self.default_pose = self.eyepose_sum / (index + 1)
        # res = self.eyepose_render(self.eyepose, res)

        # return res, resized_faces, self.tdmm_weights, self.headpose, self.eyepose, timeStamp.average_time
        return None, resized_faces, self.tdmm_weights, self.headpose, self.eyepose, timeStamp.average_time

    def render_img(self, vers):
        img = np.zeros((self.render_height, self.render_width, 3), dtype=np.uint8)
        vers = vers.T.copy()
        vers[0] = vers[0] * self.render_size + self.render_width / 2
        vers[1] = vers[1] * self.render_size + self.render_height / 2
        vers[2] = vers[2] * self.render_size + self.render_height / 2
        render_res = render(img, [vers], apple.tri)
        return render_res

    def eyepose_render(self, current_pose, frame, distance=10.0):
        current_pose -= self.default_pose
        [LeftEyeYaw, LeftEyePitch, _, RightEyeYaw, RightEyePitch, _] = current_pose[0]
        EyeYaw = (LeftEyeYaw + RightEyeYaw) / 2.0
        EyePitch = (LeftEyePitch + RightEyePitch) / 2.0
        # print(EyeYaw, EyePitch)
        trans_X = np.tan((EyeYaw / np.pi * 180).astype(int) / 180 * np.pi) * distance
        trans_Y = np.tan((EyePitch / np.pi * 180).astype(int) / 180 * np.pi) * -distance

        scale = self.render_width / 10.0
        x = int(trans_X * scale + self.render_width / 2.0)
        y = int(-trans_Y * scale + self.render_height / 2.0)
        img = cv2.circle(frame, (x, y), 4, (0, 0, 255), 8)
        return img

    def parse_params(self, params):
        if self.num_class == 60:
            tdmm = params[:, :51]
            headpose = params[:, 51:54]
            eyepose = params[:, 54:]
        elif self.num_class == 57:
            tdmm = params[:, :51]
            headpose = np.zeros((len(tdmm), 3))
            eyepose = params[:, 51:]
        elif self.num_class == 51:
            tdmm = params[:, :51]
            headpose = np.zeros((len(tdmm), 3))
            eyepose = np.zeros((len(tdmm), 6))
        else:
            print("Please set correct prediction dimension.")
        return tdmm, headpose, eyepose

    def convert_2_onnx(self,onnx_path,arch,dropout,num_class):
        pretrained_path = onnx_path.replace('.onnx', '.pth')
        # 1. load model
        torch.set_grad_enabled(False)
        model = Model(base_model=arch, dropout=dropout, num_class=num_class)

        from FaceBoxes.utils.functions import load_model
        model = load_model(model, pretrained_path=pretrained_path, load_to_cpu=True)
        model.eval()

        # 2. convert
        # export with dynamic axes for various input sizes
        dummy = torch.randn(1, 3, 256, 256)
        torch.onnx.export(
            model,
            (dummy,),
            onnx_path,
            input_names=['input'],
            output_names=['output'],
            dynamic_axes={
                'input': [0, 2, 3],
                'output': [0]
            },
            do_constant_folding=True
        )
        print(f'Convert {pretrained_path} to {onnx_path} done.')


# leeeliu
import pycuda.driver as cuda
import pycuda.autoinit
import sys, os
import tensorrt as trt
sys.path.insert(1, os.path.join(sys.path[0], ".."))
import tensorRT_utils as common


TRT_LOGGER = trt.Logger(trt.Logger.WARNING)


def build_engine_onnx(model_file):
    with trt.Builder(TRT_LOGGER) as builder, builder.create_network(
            common.EXPLICIT_BATCH) as network, trt.OnnxParser(network, TRT_LOGGER) as parser:
        builder.max_workspace_size = common.GiB(1)
        # Load the Onnx model and parse it in order to populate the TensorRT network.
        with open(model_file, 'rb') as model:
            if not parser.parse(model.read()):
                print('ERROR: Failed to parse the ONNX file.')
                for error in range(parser.num_errors):
                    print(parser.get_error(error))
                return None

        profile = builder.create_optimization_profile()
        im_height, im_width = 256, 256
        profile.set_shape("input", (1, 3, im_height, im_width), (1, 3, im_height, im_width),
                          (1, 3, im_height, im_width))
        config = builder.create_builder_config()
        config.add_optimization_profile(profile)
        return builder.build_engine(network, config)
        # return builder.build_cuda_engine(network)


class LLFR_tensorRT(object):
    def __init__(self, weights, arch, dropout, f, num_class=60):
        self.weights = weights
        make_abs_path = lambda fn: os.path.join(os.path.dirname(os.path.realpath(__file__)), fn)
        onnx_path = make_abs_path(weights.replace('.pth', '.onnx'))
        if not os.path.exists(onnx_path):
            self.convert_2_onnx(onnx_path,arch, dropout, num_class)
        # self.session = onnxruntime.InferenceSession(onnx_path, None, )

        self.onnx_path = onnx_path
        self.num_class = num_class
        self.transform = transforms.Compose(
            [transforms.ToTensor(), transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.25, 0.25, 0.25])])

        self.render_size = 3000
        self.render_width = 1920
        self.render_height = 1080
        self.eyepose_sum = np.zeros((1, 6))
        self.default_pose = np.zeros((1, 6))
        self.tdmm_weights = np.zeros((1, 51))
        self.headpose = np.zeros((1, 3))
        self.eyepose = np.zeros((1, 3))

        time1 = Timer()
        time1.tic()
        # 替换1
        engine = build_engine_onnx(onnx_path)
        self.inputs, self.outputs, self.bindings, self.stream = common.allocate_buffers(engine)
        self.context = engine.create_execution_context()
        # 替换1
        time1.toc()
        f.write('\n\n time1={}'.format(time1.average_time))

    def __call__(self, img_bgr, bboxes, index, f, args):

        time2 = Timer()
        time2.tic()
        resized_faces = facebox_tool(img_bgr, bboxes)
        time2.toc()
        f.write('\n time2={}'.format(time2.average_time))

        if type(resized_faces) != np.ndarray:
            vers = apple.neu
            res = self.render_img(vers)
            cv2.putText(res, f"I can't see your face! Rendering Neutral Face!", (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
            self.eyepose = self.default_pose
            resized_faces = np.zeros((256, 256, 3))
        else:
            time3 = Timer()
            time3.tic()

            # 改1
            '''
            input_tensor = self.transform(resized_faces).unsqueeze(0)   # torch.Size([1, 3, 256, 256])
            '''
            img = self.normalize(resized_faces)
            time3.toc()
            f.write('\n time3={} \n'.format(time3.average_time))

            # output = self.model(input_tensor)
            # output = self.session.run(None, {'input': input_tensor.cpu().numpy().astype(np.float32)})

            # 改2
            '''
            time4 = Timer()
            time4.tic()
            img = input_tensor.cpu().numpy().astype(np.float32)
            time4.toc()
            f.write('\n time4={} \n'.format(time4.average_time))
            '''

            np.copyto(self.inputs[0].host, img.reshape(-1))

            timeStamp = Timer()
            timeStamp.tic()
            trt_outputs = common.do_inference_v2(self.context, bindings=self.bindings,
                                                 inputs=self.inputs, outputs=self.outputs, stream=self.stream)
            timeStamp.toc()

            trt_outputs = np.array(trt_outputs).reshape(1, 1, self.num_class)
            self.tdmm_weights, self.headpose, self.eyepose = self.parse_params(trt_outputs.squeeze(0))

            if args.check_face == 'yes':
                vers = apple.recon_rotated_vers(self.tdmm_weights, self.headpose.squeeze())
                res = self.render_img(vers)

        if args.check_face == 'yes':
            if index < 10:
               self.eyepose_sum += self.eyepose
               self.default_pose = self.eyepose_sum / (index + 1)
            res = self.eyepose_render(self.eyepose, res)
            imageio.imwrite(os.path.join(args.pic_path,'resized_face-{}.png'.format(index)), resized_faces)
        else:
            res = None

        return res, resized_faces, self.tdmm_weights, self.headpose, self.eyepose, timeStamp.average_time


    def render_img(self, vers):
       img = np.zeros((self.render_height, self.render_width, 3), dtype=np.uint8)
       vers = vers.T.copy()
       vers[0] = vers[0] * self.render_size + self.render_width / 2
       vers[1] = vers[1] * self.render_size + self.render_height / 2
       vers[2] = vers[2] * self.render_size + self.render_height / 2
       render_res = render(img, [vers], apple.tri)
       return render_res

    def eyepose_render(self, current_pose, frame, distance=10.0):
       current_pose -= self.default_pose
       [LeftEyeYaw, LeftEyePitch, _, RightEyeYaw, RightEyePitch, _] = current_pose[0]
       EyeYaw = (LeftEyeYaw + RightEyeYaw) / 2.0
       EyePitch = (LeftEyePitch + RightEyePitch) / 2.0
       # print(EyeYaw, EyePitch)
       trans_X = np.tan((EyeYaw / np.pi * 180).astype(int) / 180 * np.pi) * distance
       trans_Y = np.tan((EyePitch / np.pi * 180).astype(int) / 180 * np.pi) * -distance

       scale = self.render_width / 10.0
       x = int(trans_X * scale + self.render_width / 2.0)
       y = int(-trans_Y * scale + self.render_height / 2.0)
       img = cv2.circle(frame, (x, y), 4, (0, 0, 255), 8)
       return img

    def parse_params(self, params):
        if self.num_class == 60:
            tdmm = params[:, :51]
            headpose = params[:, 51:54]
            eyepose = params[:, 54:]
        elif self.num_class == 57:
            tdmm = params[:, :51]
            headpose = np.zeros((len(tdmm), 3))
            eyepose = params[:, 51:]
        elif self.num_class == 51:
            tdmm = params[:, :51]
            headpose = np.zeros((len(tdmm), 3))
            eyepose = np.zeros((len(tdmm), 6))
        else:
            print("Please set correct prediction dimension.")
        return tdmm, headpose, eyepose

    def convert_2_onnx(self,onnx_path,arch,dropout,num_class):
        pass

    def test_normalize(self,img):
        # img.shape(256, 256, 3)
        input_tensor1 = self.transform(img)

        mean, std = 0.5, 0.25
        input_tensor2 = torch.from_numpy( img.transpose(2, 0, 1).astype(np.float32) / 255 )
        input_tensor2 = (input_tensor2-mean)/std        # sqrt(std) = variance = 0.5

        flag = torch.all(input_tensor1 == input_tensor2)
        print('Is my normalize right?  flag=', flag)
        # Is my normalize  right?  (True)

    def normalize(self,img):
        mean, std = 0.5, 0.25
        np_array = img.transpose(2, 0, 1).astype(np.float32) / 255
        np_array = (np_array-mean)/std
        return np_array

