import sys
sys.path.append('/Applications/Autodesk/FBX Python SDK/2020.2/lib/Python37_x64/')
sys.path.append('/Applications/Autodesk/FBX Python SDK/2020.2/samples/ImportScene/')
from DisplayCommon import *
from fbx import *
from FbxCommon import *

def fbximport(pScene):
    anim_info_dict = {}
    for i in range(pScene.GetSrcObjectCount(FbxCriteria.ObjectType(FbxAnimStack.ClassId))):
        lAnimStack = pScene.GetSrcObject(FbxCriteria.ObjectType(FbxAnimStack.ClassId), i)
        DisplayAnimationStack(lAnimStack, pScene.GetRootNode(), anim_info_dict)
    return anim_info_dict

def DisplayAnimationStack(pAnimStack, pNode, anim_info_dict):
    nbAnimLayers = pAnimStack.GetSrcObjectCount(FbxCriteria.ObjectType(FbxAnimLayer.ClassId))

    for l in range(nbAnimLayers):
        lAnimLayer = pAnimStack.GetSrcObject(FbxCriteria.ObjectType(FbxAnimLayer.ClassId), l)
        DisplayAnimationLayer(lAnimLayer, pNode, anim_info_dict)

def DisplayAnimationLayer(pAnimLayer, pNode, anim_info_dict):

    DisplayChannels(pNode, pAnimLayer, anim_info_dict)
    for lModelCount in range(pNode.GetChildCount()):
        DisplayAnimationLayer(pAnimLayer, pNode.GetChild(lModelCount), anim_info_dict)


def DisplayChannels(pNode, pAnimLayer, anim_info_dict):

    node_name = pNode.GetName()
    anim_info_dict[node_name] = {}

    for each_property in ['TX', 'TY', 'TZ', 'RX', 'RY', 'RZ', 'SX', 'SY', 'SZ']:
        anim_info_dict[node_name][each_property] = []

        if each_property[0] == 'T':
            lCurve = pNode.LclTranslation.GetCurve(pAnimLayer, each_property[1],True)
        elif each_property[0] == 'S':
            lCurve = pNode.LclScaling.GetCurve(pAnimLayer, each_property[1],True)
        elif each_property[0] == 'R':
            lCurve = pNode.LclRotation.GetCurve(pAnimLayer, each_property[1],True)
        else:
            raise NotImplementedError
        if lCurve:
            lKeyCount = lCurve.KeyGetCount()
            for lCount in range(lKeyCount):
                lTimeString = ""
                lKeyValue = lCurve.KeyGetValue(lCount)
                lKeyTime = lCurve.KeyGetTime(lCount)
                res = [lKeyTime.GetTimeString(lTimeString),lKeyValue]
                try:
                    frame_idx = int(float(res[0]))
                    keyValue = float(res[1])
                    anim_info_dict[node_name][each_property].append([frame_idx, keyValue])
                except ValueError as e:
                    pass
