import sys
sys.path.append('/Applications/Autodesk/FBX Python SDK/2020.2/lib/Python37_x64/')
sys.path.append('/Applications/Autodesk/FBX Python SDK/2020.2/samples/ImportScene/')
from DisplayCommon import *
from fbx import *
from FbxCommon import *
from DisplayGlobalSettings import *


def fbxexport(pScene, anim_info_dict, lSdkManager, outpath):
    for i in range(pScene.GetSrcObjectCount(FbxCriteria.ObjectType(FbxAnimStack.ClassId))):
        lAnimStack = pScene.GetSrcObject(FbxCriteria.ObjectType(FbxAnimStack.ClassId), i)
        # lOutputString = "Animation Stack Name: "
        # lOutputString += lAnimStack.GetName()
        # lOutputString += "\n"
        # print(lOutputString)
        DisplayAnimationStack(lAnimStack, pScene.GetRootNode(), anim_info_dict)
    # print(DisplayGlobalTimeSettings(pScene.GetGlobalSettings()))
    SaveScene(lSdkManager, pScene, outpath)
    print('saved fbx:%s' % outpath)
    lSdkManager.Destroy()
    return pScene

def DisplayAnimationStack(pAnimStack, pNode, anim_info_dict):
    nbAnimLayers = pAnimStack.GetSrcObjectCount(FbxCriteria.ObjectType(FbxAnimLayer.ClassId))

    # lOutputString = "Animation stack contains "
    # lOutputString += str(nbAnimLayers)
    # lOutputString += " Animation Layer(s)"
    # print(lOutputString)

    for l in range(nbAnimLayers):
        lAnimLayer = pAnimStack.GetSrcObject(FbxCriteria.ObjectType(FbxAnimLayer.ClassId), l)

        # lOutputString = "AnimLayer "
        # lOutputString += str(l)
        # print(lOutputString)

        DisplayAnimationLayer(lAnimLayer, pNode, anim_info_dict)

def DisplayAnimationLayer(pAnimLayer, pNode, anim_info_dict):
    # lOutputString = "     Node Name: "
    # lOutputString += pNode.GetName()
    # lOutputString += "\n"
    # print(lOutputString)

    DisplayChannels(pNode, pAnimLayer, anim_info_dict)
    for lModelCount in range(pNode.GetChildCount()):
        DisplayAnimationLayer(pAnimLayer, pNode.GetChild(lModelCount), anim_info_dict)


def DisplayChannels(pNode, pAnimLayer, anim_info_dict):

    node_name = pNode.GetName()
    for each_property in anim_info_dict[node_name]:
        if each_property[0] == 'T':
            lCurve = pNode.LclTranslation.GetCurve(pAnimLayer, each_property[1],True)
        elif each_property[0] == 'S':
            lCurve = pNode.LclScaling.GetCurve(pAnimLayer, each_property[1],True)
        elif each_property[0] == 'R':
            lCurve = pNode.LclRotation.GetCurve(pAnimLayer, each_property[1],True)
        else:
            raise NotImplementedError

        if lCurve:
            lCurve.KeyModifyBegin()
            for keyframe in anim_info_dict[node_name][each_property]:
                lTime = FbxTime()
                lTime.SetFrame(keyframe[0])
                lKeyIndex = lCurve.KeyAdd(lTime)[0]
                lCurve.KeySetValue(lKeyIndex, keyframe[1])
                lCurve.KeySetInterpolation(lKeyIndex, FbxAnimCurveDef.eInterpolationCubic)
            lCurve.KeyModifyEnd()