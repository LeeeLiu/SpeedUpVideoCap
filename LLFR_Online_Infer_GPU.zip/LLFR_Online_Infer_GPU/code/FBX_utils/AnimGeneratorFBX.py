# -*- coding: utf-8 -*-
# @Date    : 2021/01/28
# @Author  : ryenzhang
# @FileName: AtomGenerator.py
# @Project : TDLEAG
# @IDE     : PyCharm
# ==============================================================================
import copy
import numpy as np
from FBX_utils.AnimParaserFBX import FBX_Parser


class Generator(object):
    def __init__(self, fbx_path, frame_list):
        self.animation_fbx_dict = None
        self.fbx_parser = FBX_Parser()
        self.fbx_parser.load_fbx(fbx_path, frame_list)
        self.bs_node_paras = self.fbx_parser.bs_node_paras
        self.frame_interval = 0
        self.anim_length = 0
        self.default_pose = np.zeros((1, 9))
        self.pose_transform_mat = np.array([-1, 1, 1, 1, -1, 1, 1, -1, 1]) * 180.0 / np.pi
        print("FBX Initial Finished!")

    def initialize_animation(self, frame_rate=30):
        self.animation_fbx_dict = copy.deepcopy(self.fbx_parser.fbx_dict)
        for each_node in self.animation_fbx_dict:
            for each_property in self.animation_fbx_dict[each_node]:
                self.animation_fbx_dict[each_node][each_property] = []
        # 设定动画帧率
        self.frame_interval = self.fbx_parser.set_frame_rate(frame_rate)

    def insert_animation_frame(self, weight_dict, pose_paras, frame_index):
        # 生成面部动画
        self.calculate_node_paras(weight_dict, frame_index)
        self.add_head_eye_animation(pose_paras, frame_index)
        # 设定动画帧长

    def calculate_node_paras(self, weight_dict, frame_index):
        if frame_index % self.frame_interval == 0:
            self.anim_length += 1
            for each_node in self.fbx_parser.node_list:
                for each_property in list(self.animation_fbx_dict[each_node].keys())[:6]:
                    current_node_anim_paras = copy.deepcopy(self.bs_node_paras[each_node][each_property])
                    new_frame = current_node_anim_paras["neutral"].copy()
                    new_frame[0] = int(frame_index/self.frame_interval)
                    for each_bs_key in weight_dict.keys():
                        new_frame[1] += weight_dict[each_bs_key] * (current_node_anim_paras[each_bs_key][1])
                    self.animation_fbx_dict[each_node][each_property].append(tuple(new_frame))

    def add_head_eye_animation(self, current_pose, frame_index):
        if frame_index % self.frame_interval == 0:
            if frame_index == 0:
                self.default_pose = current_pose.copy()

            left_X, left_Y, left_Z, right_X, right_Y, right_Z, head_X, head_Y, head_Z = self.pose_calculator(current_pose, self.default_pose)
            left_eye_ctrl = {"RX": left_X, "RZ": left_Z}
            self.write_eye_paras(int(frame_index/self.frame_interval), left_eye_ctrl, "Face_LeftEye")
            right_eye_ctrl = {"RX": right_X, "RZ": right_Z}
            self.write_eye_paras(int(frame_index/self.frame_interval), right_eye_ctrl, "Face_RightEye")
            neck_ctrl = {"RX": head_X, "RY": head_Y, "RZ": head_Z}
            self.write_head_paras(int(frame_index/self.frame_interval), neck_ctrl, "neck_01")
            # print(frame_index, left_X, right_X, left_Y, right_Y, left_Z, right_Z, head_X, head_Y, head_Z)

    def write_eye_paras(self, frame_index, trans_paras, dagNode_key):
        for each_anim_key in trans_paras.keys():
            self.animation_fbx_dict[dagNode_key][each_anim_key][frame_index] = tuple([frame_index, trans_paras[each_anim_key]])

    def write_head_paras(self, frame_index, trans_paras, dagNode_key):
        for each_anim_key in trans_paras.keys():
            new_frame = [int(frame_index), trans_paras[each_anim_key]]
            self.animation_fbx_dict[dagNode_key][each_anim_key].append(tuple(new_frame))

    def pose_calculator(self, CurrentPose, DeFaultPose=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])):
        CurrentPose -= DeFaultPose
        [head_X, head_Z, head_Y, left_X, left_Z, left_Y, right_X, right_Z, right_Y] = CurrentPose * self.pose_transform_mat
        head_Z -= 24.657
        return left_X, left_Y, left_Z, right_X, right_Y, right_Z, head_X, head_Y, head_Z

    def save_animation(self, output_path):
        if self.animation_fbx_dict:
            self.fbx_parser.set_frame_length(self.anim_length, self.frame_interval)
            self.fbx_parser.save_fbx(self.animation_fbx_dict, output_path)
        else:
            print("There is no animation to save!")
