#!/usr/bin/env bash

#python demo.py  --id 0   --h 1920 --w 1080  --input-path=test_clip.mp4
#python demo.py  --id 1   --h 1920 --w 1080  --input-path=test_clip.mp4
#python demo.py  --id 2   --h 1920 --w 1080  --input-path=test_clip.mp4
#python demo.py  --id 3   --h 1920 --w 1080  --input-path=test_clip.mp4
#python demo.py  --id 4   --h 1920 --w 1080  --input-path=test_clip.mp4
#python demo.py  --id 11   --h 1920 --w 1080  --input-path=test_clip.mp4

#python demo.py  --id 0   --h 1440 --w 810  --input-path=test_clip.mp4
#python demo.py  --id 1   --h 1440 --w 810  --input-path=test_clip.mp4
#python demo.py  --id 2   --h 1440 --w 810  --input-path=test_clip.mp4
#python demo.py  --id 3   --h 1440 --w 810  --input-path=test_clip.mp4
#python demo.py  --id 4   --h 1440 --w 810  --input-path=test_clip.mp4

#python demo.py  --id 0   --w 1440 --h 1080  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 1   --w 1440 --h 1080  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 2   --w 1440 --h 1080  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 3   --w 1440 --h 1080  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 4   --w 1440 --h 1080  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 11  --w 1440 --h 1080  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes


#python demo.py  --id 0  --w 480 --h 270  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 1  --w 480 --h 270  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 2  --w 480 --h 270  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
#python demo.py  --id 3  --w 480 --h 270  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
python demo.py  --id 4  --w 480 --h 270  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes
python demo.py  --id 11  --w 480 --h 270  --input-path=benchmark0722/benchmark0722.mp4    --check-face=no  --checkMSE=yes

