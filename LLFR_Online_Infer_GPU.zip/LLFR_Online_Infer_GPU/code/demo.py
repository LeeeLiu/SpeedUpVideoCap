# -*- coding: utf-8 -*-

__author__ = 'axuli & ryen & leeeliu'

import os
import cv2
import argparse
import imageio
import numpy as np
from tqdm import tqdm
import time

from FaceBoxes.FaceBoxes_ONNX import FaceBoxes_ONNX

from FaceBoxes.utils.timer import Timer
from weight2fbx import FBXG
import pandas as pd

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


def open_video():
    fp, fn = os.path.split(args.input_path.replace(" ", "\ "))
    # command = "ffmpeg -threads 10 -i %s -r 30 -y -crf 20 -vcodec h264 %s " % (
    #     args.input_path.replace(" ", "\ "), os.path.join(args.output_path, fn))
    # return_value = os.system(command)
    return fp, fn


def measure_speed(id, f, onnx_faceBox=False, onnx_llfr=False, rt_faceBox=False, rt_llfr=False):
    '''
    Author: leeeLiu
    Args:
        f: TXT file where forward_pass_time will be written into
        onnx_faceBox: faceBox with onnx
        onnx_llfr: llfr with onnx
        rt_faceBox: faceBox with tensorRT
        rt_llfr: llfr with tensorRT
    Returns:
        when this function ends, please open TXT file and check the result.
    '''

    fp, fn = open_video()
    videoCapture = cv2.VideoCapture()
    videoCapture.open(args.input_path.replace(" ", "\ "))
    frame_num = videoCapture.get(cv2.CAP_PROP_FRAME_COUNT)
    frame_rate = videoCapture.get(cv2.CAP_PROP_FPS)
    height = int(videoCapture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    width = int(videoCapture.get(cv2.CAP_PROP_FRAME_WIDTH))
    arch, dropout = parse_model()

    if rt_llfr:
        from llfr import LLFR_tensorRT
        llfr = LLFR_tensorRT(args.weights, arch, dropout, f, num_class=args.num_class)
    else:
        if onnx_llfr:
            from llfr import LLFR_ONNX
            llfr = LLFR_ONNX(args.weights, arch, dropout, f, num_class=args.num_class)
        else:
            from llfr import LLFR
            llfr = LLFR(args.weights, arch, dropout, f, num_class=args.num_class)

    if rt_faceBox:
        from FaceBoxes.FaceBoxes_tensorRT import FaceBoxes_tensorRT
        faceboxes = FaceBoxes_tensorRT(args.w, args.h)
    else:
        if onnx_faceBox:
            faceboxes = FaceBoxes_ONNX()
        else:
            from FaceBoxes.FaceBoxes import FaceBoxes
            faceboxes = FaceBoxes()

    fbxg = FBXG()
    fbxg.initialize_anim(frame_rate)
    # video_wfp = os.path.join(args.output_path, fn).replace('.mp4', '_res{}.mp4'.format(id))
    video_wfp = os.path.join(args.output_path, 'h={}-w={}-id={}.mp4'.format(args.h, args.w, id))
    writer = imageio.get_writer(video_wfp, fps=frame_rate)

    A = []
    B = []
    total_A = Timer()
    total_B = Timer()

    tdmm_path = os.path.join("benchmark0722", "benchmark0722.csv")
    tdmm_frames = pd.read_csv(tdmm_path)
    tdmm_num = tdmm_frames.count()[0]
    MSE = []

    for index in tqdm(range(int(frame_num))):
        success, frame_BGR = videoCapture.read()
        # frame_bgr = frame_BGR
        # (1080, 1920, 3)
        h, w = args.h, args.w
        frame_bgr = np.array([cv2.resize(roi_face, (h, w)) for roi_face in frame_BGR.transpose((2, 0, 1))]).transpose(1,
                                                                                                                      2,
                                                                                                                      0)
        total_A.tic()
        bboxes, timeA = faceboxes(frame_bgr)
        total_A.toc()

        total_B.tic()
        res, cropped_face, tdmm_weights, headpose, eyepose, timeB = llfr(frame_bgr, bboxes, index, f, args)
        total_B.toc()

        A.append(timeA)
        B.append(timeB)

        if args.checkMSE == 'yes':
            mse = cal_MSE(index, tdmm_frames, tdmm_weights, headpose, eyepose)
            MSE.append(mse)

        if args.check_face == 'yes':
            frame_bgr[-256:, -256:, :] = cropped_face
            image = np.concatenate((frame_BGR, res), axis=1)
            writer.append_data(image[..., ::-1])

        if args.save_fbx:
            fbxg.process(tdmm_weights[0], np.concatenate((headpose[0], eyepose[0])), index)

    f.write('When onnx_faceBox={}, onnx_llfr={}, '.format(onnx_faceBox, onnx_llfr))
    f.write('rt_faceBox={},   rt_llfr={} \n'.format(rt_faceBox, rt_llfr))
    f.write('forward_time: a {:.4f}s     b {:.4f}s    \n'
            .format(np.mean(np.array(A)), np.mean(np.array(B))))
    f.write('Module_time:  A {:.4f}s     B {:.4f}s      total: {:.4f}s  \n\n'
            .format(total_A.average_time, total_B.average_time, total_A.average_time + total_B.average_time))

    if args.checkMSE == 'yes':
        avgMSE = np.mean(np.array(MSE))
        f.write('\n avgMSE={} \n'.format(avgMSE))

    writer.close()

    if not args.save_video:
        os.system("rm %s" % os.path.join(args.output_path, fn))
    if args.save_fbx:
        fbxg.save_animation(os.path.join(args.output_path, fn).replace(".mp4", ""))
        print(f"Animation Dump to %s" % os.path.join(args.output_path, fn).replace(".mp4", ".fbx"))

    if args.check_face == 'yes':
        print(f'Video save to {video_wfp}')


def parse_model():
    arch = os.path.split(args.weights)[-1].split('_')[0]
    dropout = float(os.path.split(args.weights)[-1].split('_')[1])
    return arch, dropout


# def run_offline_image():
#     pass

# def run_offline_video():
#     fp, fn = os.path.split(args.input_path.replace(" ", "\ "))
#     command = "ffmpeg -threads 10 -i %s -r 30 -y -crf 20 -vcodec h264 %s " % (
#         args.input_path.replace(" ", "\ "), os.path.join(args.output_path, fn))
#     return_value = os.system(command)
#
#     videoCapture = cv2.VideoCapture()
#     videoCapture.open(os.path.join(args.output_path, fn))
#     frame_num = videoCapture.get(cv2.CAP_PROP_FRAME_COUNT)
#     frame_rate = videoCapture.get(cv2.CAP_PROP_FPS)
#     height = int(videoCapture.get(cv2.CAP_PROP_FRAME_HEIGHT))
#
#     arch, dropout = parse_model()
#     llfr = LLFR(args.weights, arch, dropout, num_class=args.num_class)
#     faceboxes = FaceBoxes_ONNX()
#     fbxg = FBXG()
#     fbxg.initialize_anim(frame_rate)
#     video_wfp = os.path.join(args.output_path, fn).replace('.mp4', '_res.mp4')
#     writer = imageio.get_writer(video_wfp, fps=frame_rate)
#
#     for index in tqdm(range(int(frame_num))):
#         success, frame_bgr = videoCapture.read()
#         bboxes = faceboxes(frame_bgr)
#         res, cropped_face, tdmm_weights, headpose, eyepose = llfr(frame_bgr, bboxes, index)
#         frame_bgr[-256:, -256:, :] = cropped_face
#         image = np.concatenate((frame_bgr, res), axis=1)
#         writer.append_data(image[..., ::-1])
#         if args.save_fbx:
#             fbxg.process(tdmm_weights[0], np.concatenate((headpose[0], eyepose[0])), index)
#     writer.close()
#     if not args.save_video:
#         os.system("rm %s" % os.path.join(args.output_path, fn))
#     if args.save_fbx:
#         fbxg.save_animation(os.path.join(args.output_path, fn).replace(".mp4", ""))
#         print(f"Animation Dump to %s" % os.path.join(args.output_path, fn).replace(".mp4", ".fbx"))
#     print(f'Video Dump to {video_wfp}')

# def run_online_video():
#     arch, dropout = parse_model()
#     llfr = LLFR(args.weights, arch, dropout, num_class=args.num_class)
#     faceboxes = FaceBoxes_ONNX()
#
#     # # Given a came
#     reader = imageio.get_reader("<video0>", input_params=['-framerate', '30'])  # rgb
#     [width, height] = reader.get_meta_data()['size']
#     if args.save_video:
#         video_wfp = os.path.join(args.output_path, time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime()) + '_res.mp4')
#         writer = imageio.get_writer(video_wfp, fps=30)
#     for i, frame in tqdm(enumerate(reader)):
#         st = time.time()
#         frame_bgr = frame[..., ::-1]  # RGB->BGR
#         bboxes = faceboxes(frame_bgr)
#
#         res, cropped_face, tdmm_weights, headpose, eyepose = llfr(frame_bgr, bboxes, i)
#         frame_bgr[-256:, -256:, :] = cropped_face
#         image = np.concatenate((frame_bgr, res), axis=1)
#         cost = time.time() - st
#         fps = 1.0 / cost
#         image = cv2.putText(image, f"%dx%d %.2f FPS" % (width, height, fps), (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL,
#                             1.2, (0, 255, 0), 2)
#         cv2.imshow('res_video', image)
#         if args.save_video:
#             writer.append_data(image[..., ::-1])
#         if (cv2.waitKey(20) & 0xff == ord('q')):
#             break
#     if args.save_video:
#         writer.close()
#         print(f'Video Dump to {video_wfp}')

# def run_online_compare():
#     arch, dropout = parse_model()
#     llfr = LLFR(args.weights, arch, dropout, num_class=args.num_class)
#     llfr_compared = LLFR(args.weights_compared, arch, dropout, num_class=args.num_class_compared)
#     faceboxes = FaceBoxes_ONNX()
#
#     # # Given a came
#     reader = imageio.get_reader("<video0>", input_params=['-framerate', '30'])  # rgb
#     [width, height] = reader.get_meta_data()['size']
#     if args.save_video:
#         video_wfp = os.path.join(args.output_path, time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime()) + '_res.mp4')
#         writer = imageio.get_writer(video_wfp, fps=30)
#     for i, frame in tqdm(enumerate(reader)):
#         st = time.time()
#         frame_bgr = frame[..., ::-1]  # RGB->BGR
#         bboxes = faceboxes(frame_bgr)
#
#         res, cropped_face, tdmm_weights, headpose, eyepose = llfr(frame_bgr, bboxes, i)
#         res_compared, cropped_face_compared, tdmm_weights, headpose, eyepose = llfr_compared(frame_bgr, bboxes, i)
#         frame_bgr[-256:, -256:, :] = cropped_face
#         res = cv2.putText(res, "new model", (30, 100), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2, (0, 255, 0), 2)
#         res_compared = cv2.putText(res_compared, "old model", (30, 100), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.2,
#                                    (0, 255, 0), 2)
#         image = np.concatenate((frame_bgr, res, res_compared), axis=1)
#         cost = time.time() - st
#         fps = 1.0 / cost
#         image = cv2.putText(image, f"%dx%d %.2f FPS" % (width, height, fps), (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL,
#                             1.2, (0, 255, 0), 2)
#         cv2.imshow('res_video', image)
#         if args.save_video:
#             writer.append_data(image[..., ::-1])
#         if (cv2.waitKey(20) & 0xff == ord('q')):
#             break
#     if args.save_video:
#         writer.close()
#         print(f'Video Dump to {video_wfp}')

# def run_online_video_cv2():
#     arch, dropout = parse_model()
#     llfr = LLFR(args.weights, arch, dropout, num_class=args.num_class)
#     faceboxes = FaceBoxes_ONNX()
#
#     # # Given a came
#     videoCapture = cv2.VideoCapture(0)
#     width = videoCapture.get(3)
#     height = videoCapture.get(4)
#     success, frame_bgr = videoCapture.read()
#     i = 0
#     while success:
#         st = time.time()
#         bboxes = faceboxes(frame_bgr)
#         res, cropped_face = llfr(frame_bgr, bboxes, i)
#         i += 1
#         frame_bgr[-256:, -256:, :] = cropped_face
#         image = np.concatenate((frame_bgr, res), axis=1)
#         cost = time.time() - st
#         fps = 1.0 / cost
#         image = cv2.putText(image, f"%dx%d %.2f FPS" % (width, height, fps), (30, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL,
#                             1.2, (0, 255, 0), 2)
#         cv2.imshow('res_video', image)
#         if (cv2.waitKey(20) & 0xff == ord('q')):
#             break
#         success, frame_bgr = videoCapture.read()

def cal_MSE(frame_index, tdmm_frames, weights, headpose, eyepose):
    tdmm_paras = ["%.6f" % each_weight for each_weight in tdmm_frames.iloc[frame_index][tdmm_frames.columns[2:-1]]]
    tdmm_weights = np.array(tdmm_paras[:51]).reshape(1 ,-1).astype(np.float32)
    tdmm_headpose = np.array(tdmm_paras[52:55]).reshape(1 ,-1).astype(np.float32)
    tdmm_eyepose = np.array(tdmm_paras[55:61]).reshape(1 ,-1).astype(np.float32)

    diff1 = np.mean(abs(weights -tdmm_weights))
    diff2 = np.mean(abs(headpose - tdmm_headpose))
    diff3 = np.mean(abs(eyepose - tdmm_eyepose))

    mse = (diff1 +diff2 +diff3 ) /3.0
    return mse


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-face", type=str, default='no')
    parser.add_argument("--checkMSE", type=str, default='yes')
    parser.add_argument('--id', type=int, default=1)
    parser.add_argument('--w', type=int, default=480)
    parser.add_argument('--h', type=int, default=270)

    # parser.add_argument('--h', type=int, default=480)
    # parser.add_argument('--w', type=int, default=270)

    parser.add_argument('--input-path', type=str, default="./benchmark0722/benchmark0722.mp4")
    parser.add_argument('--pic-path', type=str)
    parser.add_argument('--output-path', type=str)

    parser.add_argument("--mode", type=str, default="measure_speed")
    parser.add_argument("--video-tool", type=str, default="imageio")  # imageio or opencv
    parser.add_argument("--save-video", type=bool, default=False)
    # todo 优化三重循环，修改这里参数
    parser.add_argument("--save-fbx", type=bool, default=False)

    parser.add_argument('--weights', type=str,
                        default="./checkpoints/mobilenetv3small_0.5_wpdc_checkpoint_epoch_46_withALL.pth.tar")

    parser.add_argument('--num-class', type=int, default=60)
    parser.add_argument('--weights-compared', type=str,
                        default="./checkpoints/mobilenetv3small_0.5_wpdc_checkpoint_epoch_40.pth.tar")
    parser.add_argument('--num-class-compared', type=int, default=51)
    args = parser.parse_args()

    args.output_path = os.path.join("result", 'h={}-w={}-id={}'.format(args.h, args.w, args.id))
    args.pic_path = os.path.join(args.output_path, 'pic')
    if not os.path.exists(args.pic_path):
        os.makedirs(args.pic_path)

    '''
    if args.mode == "webcam":
        if args.video_tool == "imageio":
            run_online_video()
        elif args.video_tool == "opencv":
            run_online_video_cv2()
    elif args.mode == "video":
        run_offline_video()
    elif args.mode == "image":
        run_offline_image()
    elif args.mode == "compare":
        run_online_compare()
    else:
        print("Please select correct mode.")
    '''

    if args.mode == "measure_speed":
        txt_file = os.path.join(args.output_path, 'h={}-w={}-id={}.txt'.format(args.h, args.w, args.id))
        f = open(txt_file, "w")
        if args.id == 0:
            measure_speed(0, f)
        if args.id == 1:
            measure_speed(1, f, onnx_faceBox=True)
        if args.id == 2:
            measure_speed(2, f, onnx_faceBox=True, onnx_llfr=True)

        # only GPU
        if args.id == 3:
            measure_speed(3, f, onnx_faceBox=True, onnx_llfr=True, rt_faceBox=True)
        # only GPU
        if args.id == 4:
            measure_speed(4, f, onnx_faceBox=True, onnx_llfr=True, rt_faceBox=True, rt_llfr=True)
        # only GPU
        if args.id == 11:
            measure_speed(11, f, onnx_faceBox=True, onnx_llfr=True, rt_llfr=True)

        f.close()

